// CodeGuard Sample Repo - Math Utility
export function calculateSum(numbers: number[]): number {
  return numbers.reduce((acc, curr) => acc + curr, 0);
}
