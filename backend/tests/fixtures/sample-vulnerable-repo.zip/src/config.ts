// CodeGuard Sample Repo - Configuration
export const AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE";
export const APP_ENV = "production";
export const PORT = 8080;
