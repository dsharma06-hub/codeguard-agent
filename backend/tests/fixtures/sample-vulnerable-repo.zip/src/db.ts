// CodeGuard Sample Repo - Database Access
export async function findUserById(req: any, db: any) {
  const userId = req.query.id;
  const sql = "SELECT * FROM users WHERE id = '" + userId + "'";
  return await db.query(sql);
}
