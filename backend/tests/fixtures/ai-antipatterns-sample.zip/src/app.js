const express = require('express');
const authRoutes = require('./routes/auth');

const app = express();
app.use(express.json());

// Routes mounted without global or route-level rate limiting
app.use('/auth', authRoutes);

app.listen(3000, () => {
    console.log('App running on port 3000');
});

module.exports = app;
