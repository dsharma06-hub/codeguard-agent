const express = require('express');
const router = express.Router();

// Sensitive authentication endpoint without rate limiting
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    res.json({ token: 'jwt-session-token' });
});

// Sensitive registration endpoint without rate limiting
router.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    res.json({ id: 101, username });
});

// Sensitive password reset endpoint without rate limiting
router.post('/reset-password', (req, res) => {
    const { email } = req.body;
    res.json({ message: 'Password reset link sent' });
});

module.exports = router;
