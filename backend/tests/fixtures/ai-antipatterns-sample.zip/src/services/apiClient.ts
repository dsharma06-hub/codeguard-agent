import axios from 'axios';

// Hardcoded production endpoint in fetch() call
export async function fetchUserData() {
    const response = await fetch("https://api.mycompany.com/v1/users");
    return response.json();
}

// Hardcoded production endpoint in axios.post() call
export async function processPayment(paymentDetails: any) {
    const response = await axios.post("https://production.codeguard.io/api/checkout", paymentDetails);
    return response.data;
}

// Hardcoded production endpoint in axios config object
export async function fetchTelemetry() {
    return await axios({
        method: 'get',
        url: "https://backend.prod.codeguard.io/metrics"
    });
}
